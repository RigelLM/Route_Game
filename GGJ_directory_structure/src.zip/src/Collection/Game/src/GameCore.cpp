#include "GameCore.h"

GameState State = MainMenu;

Maps MapState = town;

Maps LastMap = None;

Time GameTime = day;